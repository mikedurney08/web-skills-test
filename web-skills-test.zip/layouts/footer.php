<!-- FOOTER -->

<footer>
	<div class="section">
		<div class="container">
			<div class="columns is-multiline is-mobile">
                <div class="column is-4-desktop is-12-mobile">
                    <p>In partnership with:</p>
                    <a href="https://www.mctimoney-college.ac.uk/" target="_blank" rel="noopener">
                        <img src="/images/mctimoney-logo.png" alt="McTimoney College of Chiropractic logo" width="100%" height="auto">
                    </a>
                </div>
				<div class="column is-4-desktop is-12-mobile">
                    <h4>Get In Touch</h4>
                    <p><i class="fas fa-phone"></i><a href="tel:01235 523 336">01235 523 336</a></p>
      				<a href="https://www.facebook.com/McTimoney-College-of-Chiropractic-321932004534008/" target="_blank"><i class="fab fa-facebook-f"></i></a>
  				</div>
  				<div class="column is-12 has-text-centered">
                    <p>&copy; Copyright <script>document.write(new Date().getFullYear())</script> Ulster University </p>
  				</div>
  			</div>
  		</div>
  	</div>
</footer>

</body>
</html>