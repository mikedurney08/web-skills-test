<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Learn from professionally qualified staff in state of the art facilities along with a close working relationship with professional bodies and rewarding placements.">
		<meta name="keywords" content="Health Sciences, School of Health Sciences, Ulster University">
        <meta name="author" content="Sara Fleming">
		<meta property="og:title" content="School of Health Sciences at Ulster University" />
    	<meta property="og:description" content="Learn from professionally qualified staff in state of the art facilities along with a close working relationship with professional bodies and rewarding placements." />
    	<meta property="og:url" content="https://www.ulster.ac.uk" />
		<meta property="og:image" content="/images/school-of-health-sciences.jpg" />
		<meta property="og:image:secure_url" content="/images/school-of-health-sciences.jpg" />
		<meta property="og:image:type" content="image/jpeg" />
		<meta property="og:image:alt" content="School of Health Sciences" />

       	<title>School of Health Sciences | Ulster University</title>

		<!-- BULMA -->

       	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.2/css/bulma.min.css">

		<!-- FONT AWESOME -->

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

		<!-- FONTS -->

		<link rel="stylesheet" href="https://use.typekit.net/yzn2jjk.css">

		<!-- CSS -->

		<link rel="stylesheet" href="/css/header.css">
		<link rel="stylesheet" href="/css/footer.css">
		<link rel="stylesheet" href="/css/main.css">

		<!-- JQUERY -->

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

		<!-- FAVICON -->
    	<link rel="icon" type="image/png" href="/images/favicon.png" alt="Favicon">
    </head>

<body>
