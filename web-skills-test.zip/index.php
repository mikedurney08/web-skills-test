<?php include 'layouts/head.php';?>
<?php include 'layouts/header.php';?>

<div class="section" id="school-of-health-sciences">
    <div class="overlay"></div>
    <div class="container">
        <div class="columns is-multiline is-mobile has-text-centered">
            <div class="column is-10-desktop is-offset-1-desktop is-12-mobile">
                <div class="intro">
                    <h1>School of Health Sciences</h1>
                    <h5>Learn from professionally qualified staff in state of the art facilities along with a close working relationship with professional bodies and rewarding placements.</h5>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section" id="about">
    <div class="container">
        <div class="columns is-multiline is-mobile">
            <div class="column is-12-desktop is-12-mobile">
                <h1>The McTimoney College of Chiropractic</h1>
                <h2>About</h2>
                <p>Established in 1972, the internationally recognised McTimoney College of Chiropractic is one of the oldest dedicated providers of chiropractic education in Europe.</p>
                <p>Through a blended learning approach delivered by academic experts many of them practitioners, students are taught the art, science and philosophy of chiropractic.</p>
                <p>The McTimoney College delivers a range of undergraduate and postgraduate programmes to ensure individuals are equipped with the skills and knowledge to embark on and to progress a fulfilling career in chiropractic.</p>
                <p>Our programmes include our GCC and ECCE accredited full-time and part-time Master of Chiropractic (MChiro). This includes a unique pathway specifically designed to allow you to continue working while studying. 
                We also offer an Access Diploma in Health together with a Graduate Certificate in Animal Therapy and an MSc in Animal Manipulation.</p>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Mission</h2>
                <p>The purpose of the McTimoney College of Chiropractic is to educate and train students to be competent in the philosophy, science and art of chiropractic, in order to benefit patients.</p>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Student Experience</h2>
                <p>At the McTimoney College we are passionate about ensuring every aspect of our student’s learning experience is a positive and fulfilling one. From delivery of our education and training by highly experienced practitioners to the extensive support structures we have in place, we are committed to ensuring students enjoy their time with us and feel supported at every stage.</p>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/fNr-TNIx4RY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/kI2jz2fuxL0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/dkSk4VZGQGU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Employability</h2>
                <p>We are proud of our exemplary track record in preparing students for their future career in chiropractic and ensuring students’ progress on to employment or post graduate education. The McTimoney College has a track record of 96% of students entering practice after graduation or progressing on to further postgraduate studies.</p>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Facilities</h2>
                <p>The College delivers teaching from two locations: a purpose-built centre in Abingdon, just outside Oxford, and a centre in central Manchester. Our state-of-the-art facilities ensure students experience a first-class education experience.</p>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>History</h2>
                <p>The McTimoney College of Chiropractic is now part of the College of Health and its degrees are awarded by Ulster University.</p>
                <p>The McTimoney College began as the Oxfordshire School of Chiropractic, founded by John McTimoney in 1972. By training a small number of pupils, he aimed to increase the availability of the treatment he had developed and to ensure that his techniques would not be lost.</p>
                <P>Since its inception the McTimoney College has grown from strength to strength over the last 50-years to become one of Europe’s leading dedicated providers of chiropractic education.</p>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Get More Information</h2>
                <p>If you would like to learn more about our chiropractic programmes and discuss any questions you may have, please do not hesitate to <a href="#contact">contact us</a>.</p>
            </div>
        </div>
    </div>
</div>

<div class="section" id="contact">
    <div class="container">
        <div class="columns is-multiline is-mobile">
            <div class="column is-12">
                <h2>Contact</h2>
            </div>
            <div class="column is-3-desktop is-6-mobile">
                <img src="/images/gayle-hoffman.png" alt="Image of Gayle Hoffman" width="100%" height="auto">
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <h4>Gayle Hoffman</h4>
                <p>Director of Student Services</p>
                <p>The McTimoney College of Chiropractic</p>
                <div class="contact-details">
                    <p><i class="fas fa-phone"></i><a href="tel:"+44 1235 468575>+44 1235 468575</a></p>
                    <p><i class="fas fa-envelope"></i><a href="mailto:admissions@mctimoney-college.org.uk">admissions@mctimoney-college.org.uk</a></p>
                    <p><i class="fas fa-globe"></i><a href="https://www.mctimoney-college.ac.uk/">www.mctimoney-college.ac.uk</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section" id="programmes">
    <div class="container">
        <div class="columns is-multiline is-mobile">
            <div class="column is-12-desktop is-12-mobile has-text-centered">
                <h1>Programmes</h1>
            </div>
            <div class="column is-12-desktop is-12-mobile">
                <h2>Undergraduate Courses</h2>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <div class="course">
                    <figure class="image is-square">
                        <img src="/images/dog-and-cat.jpg" alt="Image of dog and cat with vet" width="100%" height="auto">
                    </figure>
                    <div class="course-details">
                        <h4>Master of Chiropractic (MChiro)</h4>
                        <p class="excerpt">Our Master of Chiropractic (MChiro) brings together academic, practical and clinical components to equip you with the essential s...</p>
                        <a href="https://www.bpp.com/courses/chiropractic/mchiro-masters-in-chiropractic" target="_blank" rel="noopener"><button class="" aria-label="button">More information</button></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="columns is-multiline is-mobile">
            <div class="column is-12-desktop is-12-mobile">
                <h2>Postgraduate Courses</h2>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <div class="course">
                    <figure class="image is-square">
                        <img src="/images/puppy.jpg" alt="Image of puppy being checked by vet" width="100%" height="auto">
                    </figure>
                    <div class="course-details">
                        <h4>Graduate Certificate in Animal Therapy</h4>
                        <p class="excerpt">If you hold a degree in equine, animal or veterinary science and wish to add animal massage to your skillset as a route to becoming a professional animal manipulator, our Graduate Ce...</p>
                        <a href="https://www.bpp.com/courses/chiropractic/graduate-certificate-in-animal-therapy" target="_blank" rel="noopener"><button class="" aria-label="button">More information</button></a>
                    </div>
                </div>
            </div>
            <div class="column is-4-desktop is-12-mobile">
                <div class="course">
                    <figure class="image is-square">
                        <img src="/images/horse.jpg" alt="Image of woman stroking horse" width="100%" height="auto">
                    </figure>
                    <div class="course-details">
                        <h4>MSc Animal Manipulation (Chiropractic) or (Osteopathy)</h4>
                        <p class="excerpt">The programme is designed for you if you already have training in hands-on therapy (including a trained chiropractor, physiotherapist...</p>
                        <a href="https://www.bpp.com/courses/chiropractic/msc-animal-manipulation" target="_blank" rel="noopener"><button class="" aria-label="button">More information</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'layouts/footer.php';?>